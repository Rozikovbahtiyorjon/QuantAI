import pandas as pd
import pytest

from src.fast_vector_backtester import (
    FastVectorBacktester,
    FastVectorBacktestResult,
)


def make_df(
    prices,
    signals,
):
    return pd.DataFrame(
        {
            "close": prices,
            "signal": signals,
        }
    )


def test_initialization():
    backtester = FastVectorBacktester()

    assert backtester.initial_balance == 1000.0
    assert backtester.commission == 0.0004
    assert backtester.quantity == 1.0
    assert backtester.result is None


def test_invalid_initial_balance():
    with pytest.raises(ValueError):
        FastVectorBacktester(
            initial_balance=0
        )


def test_invalid_commission():
    with pytest.raises(ValueError):
        FastVectorBacktester(
            commission=-0.01
        )


def test_invalid_quantity():
    with pytest.raises(ValueError):
        FastVectorBacktester(
            quantity=0
        )


def test_invalid_dataframe_type():
    backtester = FastVectorBacktester()

    with pytest.raises(TypeError):
        backtester.run([1, 2, 3])


def test_empty_dataframe():
    backtester = FastVectorBacktester()

    with pytest.raises(ValueError):
        backtester.run(
            pd.DataFrame()
        )


def test_missing_close_column():
    backtester = FastVectorBacktester()

    df = pd.DataFrame(
        {
            "signal": ["BUY"]
        }
    )

    with pytest.raises(ValueError):
        backtester.run(df)


def test_missing_signal_column():
    backtester = FastVectorBacktester()

    df = pd.DataFrame(
        {
            "close": [100.0]
        }
    )

    with pytest.raises(ValueError):
        backtester.run(df)


def test_invalid_price():
    backtester = FastVectorBacktester()

    df = make_df(
        [100.0, 0.0],
        ["BUY", "CLOSE"],
    )

    with pytest.raises(ValueError):
        backtester.run(df)


def test_invalid_nan_price():
    backtester = FastVectorBacktester()

    df = make_df(
        [100.0, float("nan")],
        ["BUY", "CLOSE"],
    )

    with pytest.raises(ValueError):
        backtester.run(df)


def test_hold_only():
    backtester = FastVectorBacktester()

    df = make_df(
        [100.0, 101.0, 102.0],
        ["HOLD", "HOLD", "HOLD"],
    )

    result = backtester.run(df)

    assert isinstance(
        result,
        FastVectorBacktestResult,
    )

    assert result.total_trades == 0
    assert result.total_profit == 0.0
    assert result.final_balance == 1000.0
    assert result.win_rate == 0.0


def test_long_profitable_trade():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0, 110.0],
        ["BUY", "CLOSE", "HOLD"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.winning_trades == 1
    assert result.losing_trades == 0
    assert result.total_profit == 10.0
    assert result.final_balance == 1010.0
    assert result.win_rate == 100.0


def test_long_losing_trade():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 90.0],
        ["BUY", "CLOSE"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.winning_trades == 0
    assert result.losing_trades == 1
    assert result.total_profit == -10.0
    assert result.final_balance == 990.0
    assert result.win_rate == 0.0


def test_short_profitable_trade():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 90.0],
        ["SELL", "CLOSE"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.winning_trades == 1
    assert result.total_profit == 10.0
    assert result.final_balance == 1010.0


def test_short_losing_trade():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0],
        ["SELL", "CLOSE"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.winning_trades == 0
    assert result.losing_trades == 1
    assert result.total_profit == -10.0
    assert result.final_balance == 990.0


def test_repeated_buy_does_not_open_multiple_positions():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 105.0, 110.0],
        ["BUY", "BUY", "CLOSE"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.total_profit == 10.0


def test_repeated_sell_does_not_open_multiple_positions():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 95.0, 90.0],
        ["SELL", "SELL", "CLOSE"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.total_profit == 10.0


def test_commission_is_applied():
    backtester = FastVectorBacktester(
        commission=0.001
    )

    df = make_df(
        [100.0, 110.0],
        ["BUY", "CLOSE"],
    )

    result = backtester.run(df)

    expected_profit = 10.0 - 0.21

    assert result.total_profit == pytest.approx(
        expected_profit
    )


def test_open_position_is_closed_at_end():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0],
        ["BUY", "HOLD"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.total_profit == 10.0
    assert result.final_balance == 1010.0


def test_equity_curve():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0, 90.0, 95.0],
        [
            "BUY",
            "CLOSE",
            "BUY",
            "CLOSE",
        ],
    )

    result = backtester.run(df)

    assert result.equity_curve == [
        1000.0,
        1010.0,
        1010.0,
        1015.0,
    ]


def test_max_drawdown():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0, 90.0, 90.0],
        [
            "BUY",
            "CLOSE",
            "BUY",
            "CLOSE",
        ],
    )

    result = backtester.run(df)

    assert result.max_drawdown == 20.0
    assert result.max_drawdown_percent == pytest.approx(
        1.980198,
        rel=1e-5,
    )


def test_total_return():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 120.0],
        ["BUY", "CLOSE"],
    )

    result = backtester.run(df)

    assert result.total_return == 2.0


def test_reset():
    backtester = FastVectorBacktester()

    df = make_df(
        [100.0, 110.0],
        ["BUY", "CLOSE"],
    )

    backtester.run(df)

    assert backtester.result is not None

    backtester.reset()

    assert backtester.result is None


def test_signal_case_is_normalized():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0],
        ["buy", "close"],
    )

    result = backtester.run(df)

    assert result.total_trades == 1
    assert result.total_profit == 10.0


def test_result_is_stored():
    backtester = FastVectorBacktester(
        commission=0.0
    )

    df = make_df(
        [100.0, 110.0],
        ["BUY", "CLOSE"],
    )

    result = backtester.run(df)

    assert backtester.result is result